
// Price Range Filter
const priceRangeInput = document.querySelector('input[type="range"]');
const minPriceInput = document.querySelector('.price-range input[type="text"]:first-child');
const maxPriceInput = document.querySelector('.price-range input[type="text"]:last-child');
const applyPriceButton = document.querySelector('.filter-section button.apply-btn');

priceRangeInput.addEventListener('input', function () {
    const value = priceRangeInput.value;
    maxPriceInput.value = value;
    minPriceInput.value = '0';
});

applyPriceButton.addEventListener('click', function () {
    const minPrice = minPriceInput.value;
    const maxPrice = maxPriceInput.value;
    alert(`Applied price range: $${minPrice} - $${maxPrice}`);
});

// Filter Apply
const categoryCheckboxes = document.querySelectorAll('.filter-section input[type="checkbox"]');
categoryCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        const selectedCategories = Array.from(categoryCheckboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.parentElement.textContent.trim());
        
        console.log('Selected Categories:', selectedCategories);
    });
});

// Ratings Filter
const ratingCheckboxes = document.querySelectorAll('.ratings input[type="checkbox"]');
ratingCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        const selectedRatings = Array.from(ratingCheckboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.nextSibling.textContent.trim());
        
        console.log('Selected Ratings:', selectedRatings);
    });
});

// Pagination (Simple Example)
const paginationButtons = document.querySelectorAll('.pagination button');
paginationButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        const selectedPage = e.target.textContent;
        if (selectedPage !== '<' && selectedPage !== '>') {
            console.log(`Navigating to page ${selectedPage}`);
        }
    });
});

// Product Details Toggle (View Details)
const productDetailsLinks = document.querySelectorAll('.product .view-details');
productDetailsLinks.forEach(link => {
    link.addEventListener('click', function () {
        const productDetails = this.parentElement;
        const productName = productDetails.querySelector('h3').textContent;
        alert(`Viewing details for ${productName}`);
    });
});



const gridBtn = document.getElementById('gridView');
const listBtn = document.getElementById('listView');

gridBtn.addEventListener('click', () => {
  gridBtn.classList.add('active');
  listBtn.classList.remove('active');
  // Add logic to show grid view if needed
});

listBtn.addEventListener('click', () => {
  listBtn.classList.add('active');
  gridBtn.classList.remove('active');
  // Add logic to show list view if needed
});

